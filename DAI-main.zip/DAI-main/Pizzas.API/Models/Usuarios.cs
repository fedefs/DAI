using System;
namespace Pizzas.API.Models
{
    public class Usuario
    {
        public int      Id              { get; set; }
        public string   Nombre          { get; set; }
        public string   Pizza           { get; set; }
    }
}
